import subprocess  # Импортирование модуля subprocess

# Информация для пользователя (часть 1 (1))
informationWindow1 = "echo The program has started."
returned_value1 = subprocess.call(informationWindow1, shell=True)

# Информация для пользователя (часть 2 (2))
informationWindow2 = "echo The program does the work ..."
returned_value2 = subprocess.call(informationWindow2, shell=True)

# Поиск всех файлов и каталогов с флагом "выполнение" в директории /
cmd = "find $HOME/ -type f,d -perm /a=x -ls > $HOME/ExecList/list_of_files.txt 2> $HOME/ExecList/error_log.txt"  # /* - ключевой момент при выводе
# информации в файл
returned_value = subprocess.call(cmd, shell=True)

# Информация для пользователя (часть 2.1 (3))
informationWindow3 = "echo The file list_of_files.txt has been created."
returned_value3 = subprocess.call(informationWindow3, shell=True)

# Получение отсортированного файла
cmd1 = "sort $HOME/ExecList/list_of_files.txt -k8 > $HOME/ExecList/sorted_list_of_files.txt"
returned_value8 = subprocess.call(cmd1, shell=True)

# Информация для пользователя (часть 2.2 (4))
informationWindow4 = "echo The file sorted_list_of_files.txt has been created."
returned_value4 = subprocess.call(informationWindow4, shell=True)

# Получение хеш-суммы (MD5) всех файлов с флагом "выполнение" из директории /
cmd2 = "find $HOME/* -type f -perm /a=x -exec md5sum {} \; > $HOME/ExecList/md5_sum.txt"
returned_value9 = subprocess.call(cmd2, shell=True)

# Информация для пользователя (часть 2.3 (5))
informationWindow5 = "echo The file md5_sum.txt has been created."
returned_value5 = subprocess.call(informationWindow5, shell=True)

# Получение хеш-суммы (SHA256) всех файлов с флагом "выполнение" из директории /
cmd3 = "find $HOME/* -type f -perm /a=x -exec sha256sum {} \; > $HOME/ExecList/sha256_sum.txt"
returned_value10 = subprocess.call(cmd3, shell=True)

# Информация для пользователя (часть 2.4 (6))
informationWindow6 = "echo The file sha256_sum.txt has been created."
returned_value6 = subprocess.call(informationWindow6, shell=True)

# Информация для пользователя (часть 3 (7))
informationWindow7 = "echo The program has ended."
returned_value7 = subprocess.call(informationWindow7, shell=True)


